import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { BackendComponent } from './backend/backend.component';
import { DisplayComponent } from './display/display.component';
import { LoginComponent } from './login/login.component';
import { MydemoComponent } from './mydemo/mydemo.component';
import { RegisterComponent } from './register/register.component';
import { TestingComponent } from './testing/testing.component';

const routes: Routes = [
  {path:'login' , component: LoginComponent },
  {path:'register' , component: RegisterComponent },
  {path:'display' , component: DisplayComponent },
  {path:'testing' , component: TestingComponent },
  {path:'mydemo' , component: MydemoComponent },
  {path:'backend' , component: BackendComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
