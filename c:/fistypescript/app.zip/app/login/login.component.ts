import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  name = 'Harshada';
  city = 'Pune';
  Password = '12345';

  showData():void{

    console.log(this.name+" "+this.Password+" "+this.city);
  }

  
  constructor() { }

  ngOnInit(): void {
  }

}
