export class User{
    username : any;
    password : any;
}