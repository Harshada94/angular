import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-display',
  templateUrl: './display.component.html',
  styleUrls: ['./display.component.css']
})
export class DisplayComponent implements OnInit {

  username = ""
  password = ''
  isValid = ''

  public display():void{
    console.log(this.username+" "+this.password);

    if(this.username=='Harshada' && this.password=='12345')
    {
      this.isValid="Authorised";
      console.log(this.isValid);
      this.routes.navigateByUrl("/testing");
    }
    else{
      this.isValid="Not Authorised";
      console.log(this.isValid);
      this.routes.navigateByUrl("/register");
    }
  }

  constructor(private routes:Router) { }

  ngOnInit(): void {
  }

}
