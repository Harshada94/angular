import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ng-if-else',
  template: `
  <button (click)="show = !show">{{show ? 'hide' : 'show'}}</button>
  show = {{show}}
  <br>
  <div *ngIf="show; else elseblock">Text to show</div>
  <ng-template #elseblock>Alternate Text Box When Primary Text Box Is Hidden</ng-template>
`

})
export class TestingComponent implements OnInit {

 
  

  show:boolean = true;
  constructor() { }

  ngOnInit(): void {
  }

}
