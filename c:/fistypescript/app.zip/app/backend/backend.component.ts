import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';

@Component({
  selector: 'app-display',
  templateUrl: './backend.component.html',
  styleUrls: ['./backend.component.css']
})
export class BackendComponent implements OnInit {

  fullName="Angular Programming";
  users:any;

  constructor(private service:UserService) { }

  ngOnInit(): void {
  }


  public display():void{
   
    this.service.getUsers()
    .subscribe( (response: any) =>{
      this.users=response;
      console.log(response);
    }
    );
      
  }

}