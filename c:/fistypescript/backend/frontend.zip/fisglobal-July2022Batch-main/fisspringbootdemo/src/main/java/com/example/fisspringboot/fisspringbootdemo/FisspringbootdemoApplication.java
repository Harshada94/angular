package com.example.fisspringboot.fisspringbootdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FisspringbootdemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(FisspringbootdemoApplication.class, args);
	}

}




