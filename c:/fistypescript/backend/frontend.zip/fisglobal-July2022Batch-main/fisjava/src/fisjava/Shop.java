package fisjava;

public interface Shop {
	
	int shopno=10;  // final variable 
	public void selectGoods();
	public void payment();
	public void shipment(); 
	public static void regdOffice() {
		
	}
		
}
