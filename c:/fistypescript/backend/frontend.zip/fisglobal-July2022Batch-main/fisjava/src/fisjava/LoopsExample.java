package fisjava;

public class LoopsExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i = 1;
		while (i <= 10) {
			System.out.println("Inisde the loop");
			i++;
		}
		System.out.println("after the while loop");
		int a = 1;
		do {
			System.out.println("inside the do while loop");
			a++;
		} while (a < 10);
		System.out.println("after the do while loop");
		
		
	}

}
