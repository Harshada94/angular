package com.example.angular.angular2post;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Angular2postApplicationTests {

	@Test
	void contextLoads() {
	}

}
