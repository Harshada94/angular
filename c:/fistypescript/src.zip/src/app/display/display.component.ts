import { Component, OnInit } from '@angular/core';
import { PostService } from '../post.service';
import { CommonModule } from '@angular/common';


@Component({
  selector: 'app-display',
  templateUrl: './display.component.html',
  styleUrls: ['./display.component.css']
})
export class DisplayComponent implements OnInit{

  posts:any;

  constructor(private service:PostService) { }

  ngOnInit(): void {
  }

  getPosts(){
    this.service.getAllPosts()
    .subscribe( response =>{
      this.posts=response;
      console.log(response);
    }
    );
  }

}