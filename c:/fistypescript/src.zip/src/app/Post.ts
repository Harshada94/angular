export class Post {
    pid:any;
    title:any;
    author:any;
    description:any;
}